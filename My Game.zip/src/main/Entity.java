package main;

import java.awt.Graphics;

/**
 * Abstract class extended by all entities. <br>
 * Includes stuff like x y position, width, height, hp, die function, show function...
 * @author rodri
 *
 */
public abstract class Entity {

	int x;
	int y;
	int w; // width
	int h; // height
	
	int idxX;    // x index in tile map. (tile map is a 2d array)
	int idxY;	 // y index in tile map.
	int spawner; // tile id corresponding to entity. read when out of bounds.
	
	int frame = 0; // generic timer.
	
	int DEFAULT_HP; // bro. really asking what this is??
	int hp; // current hp of entity.
	
	/**
	 * shows the entity in the given graphics.
	 * @param g
	 */
	public abstract void show(Graphics g);
	/**
	 * logic tick.
	 */
	public abstract void tick();
	
	/**
	 * default constructor.
	 * @param x
	 * @param y
	 * @param idxX
	 * @param idxY
	 */
	public Entity(int x, int y, int idxX, int idxY) {
		this(x, y, idxX, idxY, 1);
	}
	
	/**
	 * default constructor with HP.
	 * @param x
	 * @param y
	 * @param idxX
	 * @param idxY
	 * @param DEFAULT_HP
	 */
	public Entity(int x, int y, int idxX, int idxY, int DEFAULT_HP) {
		this.x = x;
		this.y = y;
		this.idxX = idxX;
		this.idxY = idxY;
		this.DEFAULT_HP = DEFAULT_HP;
		this.hp = DEFAULT_HP;
	}
	
	/**
	 * self explainatory function name
	 */
	protected void die() {
		die(true);
	}
	
	/**
	 * when argument "respawn" is true, an entity tile is placed on the <br>
	 * default position and dies. If false "only" dies.
	 * @param respawn
	 */
	protected void die(boolean respawn) {
		Main.entities.remove(this);
		if(respawn)Main.map[idxX][idxY]=spawner;
	}
	
	/**
	 * called when player is above the entity, touching the entity and moving downwards.
	 */
	protected abstract void stepedByPlayer();
	/**
	 * called when player is touching entity, but either not moving downwards or not above entity.
	 */
	protected abstract void touchedByPlayer();
	
}
